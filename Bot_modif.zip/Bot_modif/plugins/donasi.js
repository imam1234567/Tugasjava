let handler = async m => m.reply(`
╭─「 Donasi • Pulsa 」
│ • Indosat= [085812304565]
│ • Tri/3= [62895331150419]
│ • Dana= [085812304565]
╰────
╭─「 Hubungi 」
│ > Ingin donasi? Wa.me/6285812304565
╰────

Ini *#caranya untuk Donasi*
*Cara Donasi*:
1.) Beli ke pulsa/ konter terdekat semisal Indomaret
2.) Bilang ke konter terdekat..
"Beli pulsa"
3.)Dan terus masukkan nomor kami 085812304565
4.) Jika sudah kirim bukti ke sini.. Terimakasih
*Kalau tidak juga gak papa*👍🏻
`.trim()) // Tambah sendiri kalo mau
handler.help = ['donasi']
handler.tags = ['info']
handler.command = /^dona(te|si)$/i

module.exports = handler
